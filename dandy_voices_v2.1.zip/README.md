﻿Voice Forge 2.1 Character Embeddings
====================================
phil_voice.pt  - 0.13 MB  - Dry, warm baritone
jim_voice.pt   - 0.13 MB  - Energetic tenor
bryan_voice.pt - 0.13 MB  - Authoritative bass-baritone

Usage:
  from voice_forge_v2.synthesize import VoiceSynthesizer
  synth = VoiceSynthesizer()
  synth.synthesize("phil", "Your script line here")
